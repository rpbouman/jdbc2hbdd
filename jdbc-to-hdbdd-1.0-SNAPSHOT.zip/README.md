# JDBC to HDBDD Converter

This application converts database schemas from various relational databases into SAP HANA HDBDD (HANA Database Development) files. It supports both Oracle and SAP HANA source databases.

## Purpose

The tool helps in migrating database schemas to SAP HANA by:
1. Reading the source database schema via JDBC
2. Mapping source database types to HANA types
3. Generating HDBDD files that can be used in SAP HANA development

## Prerequisites

### Software Requirements
- Java 11 or higher
- Maven 3.8.x or higher
- Source Database (Oracle or SAP HANA)
- Target SAP HANA system (for HDBDD files)

### Database Drivers Installation

#### Oracle JDBC Driver
1. Download the Oracle JDBC driver (ojdbc11.jar) from Oracle's website:
   - Visit: https://www.oracle.com/database/technologies/appdev/jdbc-downloads.html
   - Download the latest ojdbc11.jar for your Java version
   
2. Place the ojdbc11.jar file in your project's `lib` directory:
```bash
mkdir -p lib
mv ojdbc11.jar lib/
```

3. Add the driver to your project's classpath:
```xml
<!-- Add to your pom.xml dependencies -->
<dependency>
    <groupId>com.oracle.database.jdbc</groupId>
    <artifactId>ojdbc11</artifactId>
    <version>21.9.0.0</version>
    <scope>system</scope>
    <systemPath>${project.basedir}/lib/ojdbc11.jar</systemPath>
</dependency>
```

#### SAP HANA JDBC Driver
1. Download the SAP HANA JDBC driver (ngdbc.jar) from SAP:
   - Visit: https://tools.hana.ondemand.com/#hanatools
   - Download the latest ngdbc.jar

2. Place the ngdbc.jar file in your project's `lib` directory:
```bash
mkdir -p lib
mv ngdbc.jar lib/
```

3. Add the driver to your project's classpath:
```xml
<!-- Add to your pom.xml dependencies -->
<dependency>
    <groupId>com.sap.cloud.db.jdbc</groupId>
    <artifactId>ngdbc</artifactId>
    <version>2.6.17</version>
    <scope>system</scope>
    <systemPath>${project.basedir}/lib/ngdbc.jar</systemPath>
</dependency>
```

### Database Access Requirements
- Source Database:
  - JDBC URL access
  - Database credentials
  - SELECT privilege on metadata tables

- Target SAP HANA:
  - HANA context name (optional)

## Quick Start

1. Build the project:
```bash
mvn clean package
```

2. Build distribution package:
```bash
mvn clean package assembly:single
```

This will create a distribution package in the `target` directory named `jdbc-to-hdbdd-1.0-SNAPSHOT.zip`. The package contains:
- The compiled JAR file
- README.md documentation
- JDBC driver files in the `lib` directory

The distribution package can be found in:
```
target/jdbc-to-hdbdd-1.0-SNAPSHOT.zip
```

2. Run the application:
```bash
java -jar target/jdbc-to-hdbdd-1.0-SNAPSHOT.jar
```

3. Follow the prompts:
   - Enter the JDBC URL for your source database
   - Enter database credentials
   - Enter the catalog and schema names
   - Enter the HANA context name (if applicable)

## Example Usage

### Oracle Source Database
```bash
java -jar target/jdbc-to-hdbdd-1.0-SNAPSHOT.jar
```

When prompted:
```
Enter JDBC URL: jdbc:oracle:thin:@//localhost:1521/orcl
Enter username: system
Enter password: ********
Enter catalog (leave empty if not applicable): 
Enter schema: SCOTT
Enter HANA context name (leave empty if not applicable): 
```

### SAP HANA Source Database
```bash
java -jar target/jdbc-to-hdbdd-1.0-SNAPSHOT.jar
```

When prompted:
```
Enter JDBC URL: jdbc:sap://localhost:39015
Enter username: SYSTEM
Enter password: ********
Enter catalog (leave empty if not applicable): 
Enter schema: _SYS_BIC
Enter HANA context name (leave empty if not applicable): 
```

## Features

- Automatic JDBC driver downloading if not found in classpath
- Intelligent type mapping from source database to HANA types
- Support for both Oracle and SAP HANA source databases
- Generation of proper HDBDD files with correct type mappings
- Support for specifying HANA context names
- Proper handling of character lengths and numeric types

## Output

The application generates HDBDD files for each table in the source database. The files will be created in the same directory as the application and will have the format:
- `tablename.hdbdd` for tables without context
- `context_tablename.hdbdd` for tables with context

Each file will contain:
1. A type definition section with proper type mappings
2. A table definition section with column definitions
3. Proper handling of primary keys
4. Correct type lengths and precision

## Notes

- The application requires proper database privileges to read metadata
- For Oracle databases, make sure the JDBC driver is accessible (it will be downloaded automatically if not found)
- For SAP HANA, ensure the system has proper privileges to read metadata
- The generated HDBDD files can be used directly in SAP HANA Studio or Web IDE

## Troubleshooting

If you encounter any issues:
1. Check that the JDBC URL is correct
2. Verify database credentials
3. Ensure proper database privileges
4. Check that the source database is accessible
5. Verify that the target directory is writable
